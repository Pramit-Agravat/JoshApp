/* istanbul ignore file */
module.exports = {
    root: true,
    extends: '@react-native-community',
    rules: {"quotes": "off", "comma-dangle": "off"}
  };
  