import { StyleSheet, Platform } from 'react-native'
import Scale from '../../../components/src/Scale';
import scale, { verticalScale } from "../../../components/src/Scale";
import { COLORS } from '../../../framework/src/Globals';

const styles = StyleSheet.create({
  keyboardPadding: { flex: 1 },

  container: {
    flex: 1,
    backgroundColor: COLORS.white
  },

  logoContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: verticalScale(60),
  },

  logoStyles: {
    height: verticalScale(50),
    width: scale(280)
  },

  logoTextStyle: {
    fontWeight: '500',
    textAlign: 'center'
  },
  logoTextView: {
    marginTop: verticalScale(12)
  },
  otpView: {
    marginTop: scale(180),
    flex: 1,

  },
  otpTimestyle: {
    marginLeft: scale(25),
    // marginTop: scale(7),
    fontSize: scale(12),
    alignSelf:'flex-start',


  },
  otpTextStyle: {
    color: COLORS.black,
    fontSize: scale(15),
    fontWeight: 'bold',
    marginLeft: scale(45)
  },
  optContainer: {
    flexDirection: 'row',
    marginTop: scale(12),
    width: scale(340),
    alignSelf: 'center',
    justifyContent: 'space-around'

  },
  firstContainer: {
    width: scale(60),
    height: scale(55),
    borderRadius: 8,
    backgroundColor: 'rgb(255,245,250)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeholderText: {
    fontSize: scale(22),
    letterSpacing: 0.75,
    color: COLORS.black,

  },
  submitButtonContainer: {
    width: scale(330),
    height: verticalScale(50),
    borderRadius: scale(8),
    backgroundColor: COLORS.blue,
    justifyContent: 'center',
    alignSelf: 'center',
    marginTop: verticalScale(30)
  },
  submitButtonText: {
    fontWeight: 'bold',
    fontSize: scale(19),
    color: '#FFFFFF',
    alignSelf: 'center',
  },
  resendSendView: {
    justifyContent: 'space-around',
    marginBottom: scale(15),
    marginLeft: scale(40),
    height: verticalScale(55)


  },
  resendtextStyle: {
    fontSize: scale(16),
    color: 'rgb(246,142,192)',
    textDecorationLine: 'underline',
    fontWeight: 'bold',


  },
  dontTextstyle: {
    color: COLORS.black,
    fontWeight: 'normal',
    fontSize: scale(16),

  },
  headerStyle: {
    flexDirection: 'row',
    marginTop: verticalScale(40),
},
backArrowStyle: {
    width: scale(20),
    height: verticalScale(20),
    marginLeft: scale(17)
},
settingStyles: {
    fontSize: scale(18),
    fontWeight: '600',
    // marginLeft: scale(110)
},
arrowViewstyle:{
  flexDirection:'row',
  width:scale(230),
  justifyContent:'space-between'

}
})


export default styles
