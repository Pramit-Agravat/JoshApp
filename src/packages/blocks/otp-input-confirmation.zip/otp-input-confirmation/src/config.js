Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.errorTitle = "Error";

exports.apiVerifyOtpContentType = "application/json";
exports.apiVerifyOtpEndPoint =
  "accounts/verify_otp";
exports.apiResendOtpEndPoint='accounts/send_otp'
exports.apiVerifyForgotPasswordOtpEndPoint =
  "forgot_password/otp_confirmation";

exports.apiVerifyOtpMethod = "POST";

exports.errorOtpNotValid = "OTP is not valid.";

exports.btnTxtLoginOtp = "Login";
exports.btnTxtSubmitOtp = "Submit";

exports.placeHolderOtp = "OTP";

exports.labelInfo =
  "We Just sent a 4 digits OTP to phone. Enter your OTP code below.";

 exports.logoText1="Lorem ipsum dolor sit amet, consectrtur adipicing";
 exports.logoText2= "edit, sidm in text";
 exports.inputHeadingText='Enter OTP';
 exports.didnotRecievedCodeLabel="Didn't received the code?";
 exports.resendLabel="Resend Code";
// exports.submitButtonColor = "#6200EE";
