import React from "react";

// Customizable Area Start
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  Button,
  ScrollView,
  TouchableWithoutFeedback,
  Platform,
  StatusBar,
  Image,
  TouchableOpacity,
  SafeAreaView,
  KeyboardAvoidingView,
} from "react-native";
// Customizable Area End
import Toast from "react-native-easy-toast";
import OTPInputAuthController, { Props } from "./OTPInputAuthController";
import styles from "../src/OTPInputAuthStyle";
import { logoImage } from "./assets";
import Loader from "../../../components/src/Loader";
import CountDown from "react-native-countdown-component";
import { COLORS } from "../../../framework/src/Globals";
import scale, { verticalScale } from "../../../components/src/Scale";
import * as IMAGECONST from './assets';

export const configJSON = require("./config");

export default class OTPInputAuth extends OTPInputAuthController {
  constructor(props: Props) {
    super(props);
    // Customizable Area Start
    // Customizable Area End
  }

  renderHeaderContainer = () =>{
    return(
      <View style={styles.headerStyle}>
         <View style={styles.arrowViewstyle}>
         <TouchableOpacity onPress={()=>this.props.navigation.goBack()}>
          <Image source={IMAGECONST.BackArrow} resizeMode="contain" style={styles.backArrowStyle} />
         </TouchableOpacity>
         <Text style={styles.settingStyles}>{configJSON.headerText}</Text>
         </View>
        
      </View>
    )
  }
  renderLogoContainer = () => {
    return (
      <View style={styles.logoContainer}>
        <Image
          source={logoImage}
          resizeMode="contain"
          style={styles.logoStyles}
        />
        <View style={styles.logoTextView}>
          <Text style={styles.logoTextStyle}>{configJSON.logoText1}</Text>
          <Text style={styles.logoTextStyle}>{configJSON.logoText2}</Text>
        </View>
      </View>
    );
  };

  renderOTPContainer = () => {
    const inputs = Array(this.state.inputBoxLength).fill(0);
    return (
      <View style={{}}>
        <View style={styles.optContainer}>
          {inputs.map((i, j) => (
            <View
              style={[
                styles.firstContainer,
                {
                  borderColor: this.state.otp[j]
                    && COLORS.darkPink,
                    borderWidth: this.state.otp[j] ?  1 : 0
                
                },
               
              ]}>
              <TextInput
                placeholder=" "
                keyboardType="numeric"
                onChangeText={(v) => this.focusNext(j, v)}
                onKeyPress={(e) => this.focusPrevious(e.nativeEvent.key, j)}
                ref={(ref) => (this.otpTextInput[j] = ref)}
                value={this.state.otp[j]}
                style={styles.placeholderText}
              />
            </View>
          ))}
        </View>
      </View>
      // Customizable Area Start
      // Customizable Area End
    );
  };

  otpTextInput = [];

  focusPrevious(key: any, index: any) {
    if (key === "Backspace" && index !== 0)
      this.otpTextInput[index - 1].focus();
  }

  focusNext(index: any, value: any) {
    if (index < this.otpTextInput.length - 1 && value) {
      this.otpTextInput[index + 1].focus();
    }
    if (index === this.otpTextInput.length - 1) {
      this.otpTextInput[index].blur();
    }
    const otp = this.state.otp;
    otp[index] = value.charAt(value.length - 1);
    this.setState({ otp });
  }

  rendreSubmitButtonContainer = () => {

    const userLoginButton = this.props.navigation.state.params.accountLogin
    console.log('this.props.navigation====================================',userLoginButton);

    return (
      <TouchableOpacity
        style={styles.submitButtonContainer}
        onPress={() => this.submitOtp()}
      >
       {userLoginButton ?  <Text style={styles.submitButtonText}>
          {configJSON.btnTxtLoginOtp}
        </Text> : <Text style={styles.submitButtonText}>
          {configJSON.btnTxtSubmitOtp}
        </Text>}
      </TouchableOpacity>
    );
  };

  otpViewContainer = () => {
    return (
      <View style={styles.otpView}>
        <Text style={styles.otpTextStyle}>{configJSON.inputHeadingText}</Text>
        {this.renderOTPContainer()}
        <View style={{flexDirection: 'row', alignItems: 'center',marginHorizontal:scale(16),marginTop:scale(7)}}>
          <Text style= {{left: 25, color: '#27b6e9'}}>(</Text>
        {this.renderCountDown()}
        <Text style={{right: 4, color: '#27b6e9'}}>)</Text>
        </View>
        {/* <Text style={styles.otpTimestyle}>(00.52)</Text> */}
      </View>
    );
  };

  renderCountDown = () =>{
    return(
      <View style={styles.otpTimestyle}>
          <CountDown
            until={this.state.countDown}
            size={7}
            onFinish={() =>  this.setState({ sendOtp: true,  isResendOtpClicked: false,})}
            id={this.state.isResendOtpClicked}
            digitStyle={{ backgroundColor: "#FFF"}}
            digitTxtStyle={{ color: "rgb(0, 187, 242)" ,fontSize: scale(12),
          }}
            // timeLabelStyle={{color: 'red', fontWeight: 'bold' }}
            timeToShow={["M", "S"]}
            timeLabels={{ m: "",s: ""}}
            separatorStyle={{color: "rgb(0, 187, 242)",fontSize: scale(12) }}
            showSeparator
          />
        </View>
    )
  }
  renderBottomView = () => { 
    return (
      <View style={{ flex: 1, justifyContent: "flex-end", marginTop: 50 }}>
        <View style={styles.resendSendView}>
          <Text style={styles.dontTextstyle}>
            {configJSON.didnotRecievedCodeLabel}
          </Text>

          <TouchableOpacity onPress={() => {this.onResendOtp()}} disabled={!this.state.sendOtp}>
            <Text style={styles.resendtextStyle}>{configJSON.resendLabel}</Text>
          </TouchableOpacity>
  
        </View>
      </View>
    );
  };
  render() {
    return (
      //Merge Engine DefaultContainer

      <SafeAreaView style={styles.container}>
        <StatusBar
          barStyle="dark-content"
          hidden={false}
          backgroundColor="#FFF"
          translucent={true}
        />
        <ScrollView>
        {this.renderHeaderContainer()}

          {this.renderLogoContainer()}
          <Loader loading={this.state.isLoading} /> 
            { this.otpViewContainer()}
          {this.rendreSubmitButtonContainer()}
          {this.renderBottomView()}
        </ScrollView>
        <Toast
          ref={(toast) => (this.toastRef = toast)}
          position={"top"}
          style={{ backgroundColor: "rgb(240,64,148)" }}
        />
      </SafeAreaView>
    );
  }
}
