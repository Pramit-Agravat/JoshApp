import { Message } from "../../../framework/src/Message";
import { BlockComponent } from "../../../framework/src/BlockComponent";
import { runEngine } from "../../../framework/src/RunEngine";
import MessageEnum, {
  getName
} from "../../../framework/src/Messages/MessageEnum";
import { getStorageData, setStorageData } from "../../../framework/src/Utilities";
import StorageProvider from "../../../framework/src/StorageProvider";
import { Alert } from "react-native";

// Customizable Area Start
// Customizable Area End

export const configJSON = require("./config");

export interface Props {
  navigation: any;
  id: string;
  // Customizable Area Start
  // Customizable Area End
}

export interface S {
  // Customizable Area Start
  otpAuthToken: string;
  inputBoxLength: any;
  otp: any[];
  isLoading:boolean;
  countDown:any;
  isResendOtpClicked:boolean;
  sendOtp:boolean,
  onShowResetext:boolean

  // Customizable Area End
}

export interface SS {
  // Customizable Area Start
  id: any;
  // Customizable Area End
}

export default class OTPInputAuthController extends BlockComponent<
  Props,
  S,
  SS
> {
  // Customizable Area Start
  otpAuthApiCallId: any;
  toastRef: any;
  apiResendOtpCallId:any
  // Customizable Area End

  constructor(props: Props) {
    super(props);
    this.subScribedMessages = [
      // Customizable Area Start
      getName(MessageEnum.RestAPIResponceMessage),
      getName(MessageEnum.NavigationPayLoadMessage)
      // Customizable Area End
    ];

    this.receive = this.receive.bind(this);

    runEngine.attachBuildingBlock(this, this.subScribedMessages);

    // Customizable Area Start
    this.state = {
      inputBoxLength: 5,
      otp: [],    
      otpAuthToken: "",
      isLoading:false,
      countDown:0 * 1 + 60,
      isResendOtpClicked:false,
      sendOtp:false,
      onShowResetext:false

      
    };

    // Customizable Area End
  }


  async componentDidMount(){

  }

  setUserToken = async (userData: any) => {
    console.log("@@@ userData Token==================", userData);
    let userToken = await StorageProvider.set("authToken", userData);
    console.log("@@@ User Token==================", userToken);
  };


  async receive(from: String, message: Message) {
    // Customizable Area Start
    if (
      getName(MessageEnum.RestAPIResponceMessage) === message.id

    ) {
      const apiRequestCallId = message.getData(
        getName(MessageEnum.RestAPIResponceDataMessage)
      );

      var responseJson = message.getData(
        getName(MessageEnum.RestAPIResponceSuccessMessage)
      );
      console.log("responseJson", responseJson)
      var errorReponse = message.getData(
        getName(MessageEnum.RestAPIResponceErrorMessage)
      );

      console.log("errorReponse", errorReponse)

      if (responseJson && responseJson.data) {
        console.log("responseIfcondition", responseJson)
        if (apiRequestCallId === this.otpAuthApiCallId) {
          this.onOTPUserSuccessCallBack(responseJson);
          this.saveLoggedInUserData(responseJson)

        }else if (apiRequestCallId === this.apiResendOtpCallId) {

          this.onResendOtpSuccessCallBack(responseJson)

        }
      } else if (responseJson && responseJson.errors) {
        console.log("responseElsecondition", responseJson)

        if (apiRequestCallId === this.otpAuthApiCallId) {

          this.onOTPUpUserFailureCallBack(responseJson);

        }else if (apiRequestCallId === this.apiResendOtpCallId) {

          this.onResendOtpFailureCallBack(responseJson)

        }

      }
      else if (errorReponse) {
        console.log("errorReponse", errorReponse)

      }
    }
  }

  onOTPUserSuccessCallBack = async (res: any) => {
    console.log('@@@ OTP User Success CallBack res.meta.token =============', res.meta.token);
    this.setUserToken(res.meta.token)
    this.setState({isLoading:false})
    this.toastRef.show(res.meta.message)
     if(res.data.attributes.account_exists){
       this.setState({countDown:0},()=>{

        this.props.navigation.navigate('BottomTabNavigator')

       })

     }else{

      let splitNum=res.data.attributes.phone_number.split('91')
      this.props.navigation.navigate('PortfolioManagement',{phoneNumber:splitNum[1]})

      }
  }
  // onOTPUserSuccessCallBack = async (res: any) => {
  //   const  userLogin  = this.props.navigation.state.params.accountLogin;
  //   const  userRegistr  = this.props.navigation.state.params.accountregistration;

  //   console.log('@@@ navigation Data =============',userLogin);
  //   this.setUserToken(res.meta.token)
  //   this.setState({isLoading:false})
  //   this.toastRef.show(res.meta.message)
  //  if(userLogin && userLogin == 'SignIn'  && !res.data.attributes.account_exists ){
  //   Alert.alert(
  //     'Alert',
  //     "Account doesn't exist Try signin",
  //     [
  //       {text: 'OK', onPress: () => this.props.navigation.navigate('EmailAccountRegistration')},
  //     ],
  // )
  
  //  }else if(userRegistr && userRegistr == 'SignUP'  && res.data.attributes.account_exists){
  //   Alert.alert(
  //     'Alert',
  //     'User is already registerd, try to Login',
  //     [
  //       {text: 'OK', onPress: () => this.props.navigation.navigate('EmailAccountLoginBlock')},
  //     ],
  //   )}   
   
  //   else if(res.data.attributes.account_exists){     
  //       this.props.navigation.replace('BottomTabNavigator')  

  //    }else {

  //     let splitNum=res.data.attributes.phone_number.split('91')
  //     this.props.navigation.navigate('PortfolioManagement',{phoneNumber:splitNum[1]})

  //     }
  // }

  onOTPUpUserFailureCallBack = (error: any) => {
    console.log('@@@ OTP User Failure CallBack ===================', error);
    this.toastRef.show("Invalid Pin for Phone Number")
    this.setState({isLoading:false})

  }


  onResendOtpSuccessCallBack = async (res: any) => {
    console.log('@@@ Resend OTP In User Success CallBack =============', res);

    this.setState({isResendOtpClicked: true,otp:'', sendOtp: false,isLoading:false},()=>{
      this.toastRef.show("Otp send successfully")

    })

  }

  onResendOtpFailureCallBack = (error: any) => {
    console.log('@@@ Resend OTP In User Failure CallBack ===================', error);
    this.setState({isLoading:false})
    
  }

  saveLoggedInUserData(responseJson: any) {
    if (responseJson && responseJson.meta && responseJson.meta.token) {
      const msg: Message = new Message(getName(MessageEnum.SessionSaveMessage));

      msg.addData(
        getName(MessageEnum.SessionResponseData),
        JSON.stringify(responseJson)
      );
      msg.addData(
        getName(MessageEnum.SessionResponseToken),
        responseJson.meta.token
      );

      this.send(msg);
    }
  }

  apiCall = async (data: any) => {
    let token = await getStorageData('SignToken')
    console.log("@@@@@@@@token",token)
    const { contentType, method, endPoint, body } = data;
    const header = {
      "Content-Type": contentType,
      token: token
    };
    const requestMessage = new Message(
      getName(MessageEnum.RestAPIRequestMessage)
    );
    requestMessage.addData(
      getName(MessageEnum.RestAPIRequestHeaderMessage),
      JSON.stringify(header)
    );
    requestMessage.addData(
      getName(MessageEnum.RestAPIResponceEndPointMessage),
      endPoint
    );
    requestMessage.addData(
      getName(MessageEnum.RestAPIRequestMethodMessage),
      method
    );
    body &&
      requestMessage.addData(
        getName(MessageEnum.RestAPIRequestBodyMessage),
        JSON.stringify(body)
      );
    runEngine.sendMessage(requestMessage.id, requestMessage);
    return requestMessage.messageId;
  };

  // Customizable Area Start
  async submitOtp() {

    if (this.state.otp.join('').length !== 5) {
      this.toastRef.show(configJSON.errorOtpNotValid);
      this.setState({isLoading:false})
      return;
    }
    
    let x = this.state.otp.toString();
    let str1 = x;
    str1.replace(/\,/g,"");
    let otpNum = str1.replace(/\,/g,"");
    let otpData = {
        pin: otpNum,
    };
    console.log("@@@@@@otpData", otpData);
    this.setState({isLoading:true})
    this.otpAuthApiCallId = await this.apiCall({
      contentType: configJSON.apiVerifyOtpContentType,
      method: configJSON.apiVerifyOtpMethod,
      endPoint: configJSON.apiVerifyOtpEndPoint,
      body: otpData,
    })

  }

  onResendOtp = async () => {
 
    const { userDetails } = this.props.navigation.state.params;
    let resenData =  {
      data: { 
      attributes: {
          full_phone_number: userDetails.full_phone_number
        }
      }
    }

    this.setState({isLoading:true,isResendOtpClicked: true,otp:''})

    console.log("@@@@@@@@@resenData", resenData)
     this.apiResendOtpCallId = await this.apiCall({
      contentType: configJSON.apiVerifyOtpContentType,
      method: configJSON.apiVerifyOtpMethod,
      endPoint: configJSON.apiResendOtpEndPoint,
      body: resenData,
     })
 }

 
  // Customizable Area End
}
