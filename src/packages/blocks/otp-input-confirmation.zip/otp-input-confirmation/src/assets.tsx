export const logoImage = require("../assets/josh.png");
export const BackArrow = require("../assets/backicon.png");
