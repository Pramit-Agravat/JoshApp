import React, { Component } from 'react'
import { Text, View } from 'react-native'
import CountDown from 'react-native-countdown-component';

export class CountDownPage extends Component {
  renderTime = () => {
    return(
      <CountDown
      until={60 * 1 + 30}
      size={10}
      digitStyle={{backgroundColor: 'white'}}
      timeToShow ={`$('M', 'S')`}
      timeLabels={{m: '', s: ''}}
      showSeparator
      running
    //   style={`(${timeToShow})`}
    />
    )
  }
  render() {
    return (
      <View style={{marginTop: 50, flexDirection: 'row', alignItems: 'center'}}>
          <Text>(</Text>
       {this.renderTime()}
       <Text>)</Text>
      </View>
    )
  }
}

export default CountDownPage